﻿document.addEventListener("deviceready", onDeviceReady, false);// Wait for device API libraries to load...

/*AngularJS Code to make Single-Page App*/
var tsApp = angular.module('tsApp', []);

tsApp.controller('LoginCtrl', function ($scope) {

})

tsApp.controller('ForgotPasswordCtrl', function ($scope) {

})
/*End AngularJS Single-Page App Code*/

/*Hide All Function*/
function hideAll() {
    document.getElementById('LoginPage').style.display = "none";
    document.getElementById('ForgotPassword').style.display = "none";
    document.getElementById('DashboardPage').style.display = "none";
    document.getElementById('ProfilePage').style.display = "none";
    document.getElementById('SettingsPage').style.display = "none";
    document.getElementById('HelpPage').style.display = "none";
    document.getElementById('TimeStudyPage').style.display = "none";
    document.getElementById('TimeStudyEntryPage').style.display = "none";
}//End Hide All...

/*Login Check Function*/
function checkLogin() {
    hideAll();
    document.getElementById('DashboardPage').style.display = "block";
}//End Login Check...

/*CheckBackButton Function*/
function CheckBackButton() {

}//End CheckBackButton Function...

/*SaveTimeSheet Function*/
function SaveTimeSheet() {
    prompt('Are you sure you want to Save?...');
}//End SaveTimeSheetFunction...

/*PlaceOnHold Function*/
function PlaceOnHold() {

}//End PlaceOnHold Function..

function LogoutConfirm() {
    hideAll();
    document.getElementById('LoginPage').style.display = "block";
}

/*Delete These When Done With Project!!!*/
function showProfile() {
    hideAll();
    document.getElementById('ProfilePage').style.display = "block";
}

function showSettings() {
    hideAll();
    document.getElementById('SettingsPage').style.display = "block";
}

function showDashboard() {
    hideAll();
    document.getElementById('DashboardPage').style.display = "block";
}

function showTimeStudy() {
    hideAll();
    document.getElementById('TimeStudyPage').style.display = "block";
}

function showTimeStudyEntry() {
    hideAll();
    document.getElementById('TimeStudyEntryPage').style.display = "block";
}

function showHelp() {
    hideAll();
    document.getElementById('HelpPage').style.display = "block";
}
/*Stop Deleting Functions Here!!!*/

/*Retrieve Password Function*/
function retrievePassword() {

}//End Retrieve Password

/*Change Profile Pic Function*/
function ChangeProfPic() {
    alert('We are now changing Profile Pic...')

}
//End Change Profile Pic Function

/*Change Settings Page Profile Pic Function*/
function SettingsChangeProfPic() {
    var preview = document.querySelector('img');
    var imgFile = document.querySelector('input[type=file]').files[0];
    var reader = new FileReader();

    reader.onloadend = function Preview() {
        preview.src = reader.result;
    }

    if (imgFile) {
        reader.readAsDataURL(imgFile);
    } else {
        preview.src = "";
    }

    alert('You just changed your pic...');
}//End Change Settings Page Profile Pic Function

/*Welcome Load Function*/
function welcomeLoad() {
    hideAll();
    document.getElementById('LoginPage').style.display = "block";
}//End WelcomeLoad Function

/*ForgotPassword Function*/
function forgot() {
    var fadeoutContainer = document.getElementById('fadeoutContainer');
    fadeoutContainer.style.opacity = 0;
    hideAll();
    document.getElementById('ForgotPassword').style.display = "block";
    fadeoutContainer.style.display = "block";

    (function fade() {
        var val = parseFloat(fadeoutContainer.style.opacity);
        if (!((val += .05) > 1)) {
            fadeoutContainer.style.opacity = val;
            requestAnimationFrame(fade);
        }
    })();
}

/*LeaveForgot Function*/
function leaveForgot() {
    var fadeoutContainer = document.getElementById('fadeoutContainer');
    fadeoutContainer.style.opacity = 1;
    fadeoutContainer.style.display = "block";

    (function fade() {
        var val = parseFloat(fadeoutContainer.style.opacity);
        if (((val -= .05) < 0)) {
            fadeoutContainer.style.display = "none";
            LoginPage.style.display = "block";
        }
        else {
            fadeoutContainer.style.opacity = val;
            requestAnimationFrame(fade);
        }
    })();
}//End LeaveForgot

/*Come Back To
$(function () {
    $('[data-toggle="tooltip"]').tooltip()
});

$(function () {
    $('[data-toggle="popover"]').popover()
});
*/

/*RadialProgressChart Script
$(function () {
    var $ppc = $('.progress-pie-chart'),
      percent = parseInt($ppc.data('percent')),
      deg = 360 * percent / 100;
    if (percent > 50) {
        $ppc.addClass('gt-50');
    }
    $('.ppc-progress-fill').css('transform', 'rotate(' + deg + 'deg)');
    $('.ppc-percents span').html(percent + '%');
});
/*End RadialProgressChart Script*/